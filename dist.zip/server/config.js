"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.serverPort = 4300;
exports.secret = "RbBQqA6uF#msRF8s7h*?@=95HUm&DgMDd6zLFn4XzWQ6dtwXSJwBX#?gL2JWf!";
exports.length = 128;
exports.digest = "sha256";
//# sourceMappingURL=E:/pros/ibm-secure/code-prac/angular2-express-starter-master/dist/server/config.js.map